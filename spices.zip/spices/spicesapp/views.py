from django.shortcuts import render,redirect
from django.http import JsonResponse
from django.http import HttpResponse
from spicesapp.form import CustomUserForm
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from . models import  *
import json
import os

# Create your views here.

def category(request):
    category=Category.objects.filter(status=0)
    return render(request,'category.html',{"category":category})

def view(request,name):
    if(Category.objects.filter(name=name,status=0)):
        products=Products.objects.filter(category__name=name)
        return render(request,"view.html",{"products":products,"category_name":name})
    else:
        messages.warning(request,"No such catagory found")
        return redirect('category')
    
def productdetail(request,cname,pname):
    if(Category.objects.filter(name=cname,status=0)):
        if(Products.objects.filter(name=pname,status=0)):
            products=Products.objects.filter(name=pname,status=0).first()
            return render(request,"productdetail.html",{"products":products})
        else:
            messages.error(request,"No such product found")
            return redirect('category')
    else:
        messages.error(request,"No such product found")
        return redirect('category')

def home(request):
    return render(request,"home.html")

def contact(request):
    return render(request,"contact.html")       

def logout_page(request):
    if request.user.is_authenticated:
        logout(request)
        messages.success(request,"Logged out Successfully")
    return redirect("home")

def login_page(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method=='POST':
        name=request.POST.get('username')
        pwd=request.POST.get('password')
        user=authenticate(request,username=name,password=pwd)
        if user is not None:
            login(request,user)
            messages.success(request,"Logged in Successfully")
            return redirect("home")
        else:
            messages.error(request,"Invalid User Name or Password")
            return redirect('login')
    return render(request,'login.html')     

def reg(request):
    form=CustomUserForm()
    if request.method=='POST':
        form=CustomUserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Registration succes")
            return redirect('login')
    return render(request,'reg.html',{"form":form})

def about(request):
    return render(request,"about.html")

def cart(request):
    if request.user.is_authenticated:
        cart=Cart.objects.filter(user=request.user)
        return render(request,"cart.html",{"cart":cart})
    else:
        return redirect('home')

def add_to_cart(request):
    if request.headers.get('x-requested-with')=='XMLHttpRequest':
        if request.user.is_authenticated:
            data=json.load(request)
            product_qty=data['product_qty']
            product_id=data['pid']
            # print(request.user.id)
            Product_status=Products.objects.get(id=product_id)
            if Product_status:
                if Cart.objects.filter(user=request.user.id,product_id=product_id):
                    return JsonResponse({'status':'Product already in Cart'},status=200)
                else:
                    if Product_status.quantity>=product_qty:
                        Cart.objects.create(user=request.user,product_id=product_id,product_qty=product_qty)
                        return JsonResponse({'status':'Product added to cart'},status=200)
                    else:
                        return JsonResponse({'status':'Product stock not Available'},status=200)
        else:
            return JsonResponse({'status':'Login to Add Cart'}, status=200)
    else:
        return JsonResponse({'status':'Invalid Access'}, status=200)
    
def remove_cart(request,cid):
    cartitem=Cart.objects.get(id=cid)
    cartitem.delete()
    return redirect('cart')

def favourite(request):
    if request.user.is_authenticated:
        fav=Favorite.objects.filter(user=request.user)
        return render(request,"favourite.html",{"fav":fav})
    else:
        return redirect('home')

def fav(request):
    if request.headers.get('x-requested-with')=='XMLHttpRequest':
        if request.user.is_authenticated:
            data=json.load(request)
            product_id=data['pid']
            Product_status=Products.objects.get(id=product_id)
            if Product_status:
                if Favorite.objects.filter(user=request.user.id,product_id=product_id):
                    return JsonResponse({'status':'Product already in Favorite'},status=200)
                else:
                     Favorite.objects.create(user=request.user,product_id=product_id)
                     return JsonResponse({'status':'Product Added to Favorite'}, status=200)
        else:
            return JsonResponse({'status':'Login to Add Favorite'}, status=200)
    else:
        return JsonResponse({'status':'Invalid Access'}, status=200)
    
def remove_fav(request,fid):
    favitem=Favorite.objects.get(id=fid)
    favitem.delete()
    return redirect('favview')
