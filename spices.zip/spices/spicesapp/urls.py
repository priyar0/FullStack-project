from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name="home"),
    path('contact',views.contact,name="contact"),
    path('login',views.login_page,name="login"),
    path('logout',views.logout_page,name="logout"),
    path('reg',views.reg,name='reg'),
    path('about',views.about,name="about"),
    path('category',views.category,name="category"),
    path('category/<str:name>',views.view,name="category"),
    path('category/<str:cname>/<str:pname>',views.productdetail,name="productdetail"),
    path('cart',views.cart,name="cart"),
    path('remove_cart/<str:cid>',views.remove_cart,name="remove_cart"),
    path('fav',views.fav,name="fav"),
    path('favourite',views.favourite,name="favourite"),
    path('remove_fat/<str:fid>',views.remove_fav,name="remove_fav"),
    path('addtocart',views.add_to_cart,name="addtocart"),
]
